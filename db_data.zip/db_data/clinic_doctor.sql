-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: clinic
-- ------------------------------------------------------
-- Server version	5.7.20-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `doctor`
--

DROP TABLE IF EXISTS `doctor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `doctor` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `PESEL` varchar(255) NOT NULL,
  `CREATEDON` datetime NOT NULL,
  `EMAIL` varchar(255) NOT NULL,
  `FIRSTNAME` varchar(255) NOT NULL,
  `ADMIN` bit(1) NOT NULL,
  `LASTNAME` varchar(255) NOT NULL,
  `SPECIALIZATIONID` int(11) NOT NULL,
  PRIMARY KEY (`ID`),
  UNIQUE KEY `UK_4fx0u77hfn5x6txu0w2c1xlek` (`PESEL`),
  UNIQUE KEY `UK_4nccvmdvy3hjrnqm665dyw3au` (`EMAIL`),
  UNIQUE KEY `UK_9v197l4qijorgmewkqye90csw` (`EMAIL`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `doctor`
--

LOCK TABLES `doctor` WRITE;
/*!40000 ALTER TABLE `doctor` DISABLE KEYS */;
INSERT INTO `doctor` VALUES (1,'99000000000','2018-01-16 22:14:22','lekarztest@localhost.com','Imie','','Nazwisko',1),(2,'99000000001','2018-01-16 22:14:45','lekarztest1@localhost.com','Imie1','','Nazwisko1',1),(3,'99000000002','2018-01-16 22:15:01','lekarztest2@localhost.com','Imie2','\0','Nazwisko2',2),(4,'99000000003','2018-01-16 22:15:14','lekarztest3@localhost.com','Imie3','\0','Nazwisko3',3),(5,'99000000004','2018-01-16 22:15:22','lekarztest4@localhost.com','Imie4','','Nazwisko4',3),(6,'99000000005','2018-01-16 22:15:42','lekarztest5@localhost.com','Imie5','','Nazwisko5',4),(7,'99000000006','2018-01-17 00:01:03','lekarztest6@localhost.com','Imie6','\0','Nazwisko6',2),(8,'99000000007','2018-01-17 00:03:32','lekarztest7@localhost.com','Imie7','\0','Nazwisko7',4),(9,'99000000008','2018-01-17 00:06:45','lekarztest8@localhost.com','Imie8','\0','Nazwisko8',3),(10,'92222222211','2018-01-17 01:03:01','lekarztest11@localhost.com','Imie11','\0','Nazwisko11',5),(11,'99111111111','2018-01-20 20:08:44','lekarztest9@localhost.com','Imie9','\0','Nazwisko9',7),(12,'991122222211','2018-01-20 20:09:59','lekarztest10@localhost.com','Imie10','\0','Nazwisko10',6),(13,'92222222299','2018-01-20 21:08:03','lekarztest12@localhost.com','Imie12','\0','Nazwisko12',5),(14,'990035345353','2018-01-20 21:09:48','lekarztest13@localhost.com','Imie13','\0','Nazwisko13',3),(15,'92134535302938','2018-01-20 21:11:44','lekarztest14@localhost.com','Imie14','\0','Nazwisko14',4),(16,'99000001234','2018-01-22 08:40:43','lekarztest113@localhost.com','Imie114','','Nazwisko114',2);
/*!40000 ALTER TABLE `doctor` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-05-28  9:34:10
